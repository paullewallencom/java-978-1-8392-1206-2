# Recursion and Dynamic Programming
This chapter covers one of the favorite topics of interviewers – recursion and Dynamic Programming. Both of these topics work hand in hand with each other, so you have to be able to cover both.
