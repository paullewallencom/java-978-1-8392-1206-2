package coding.challenge.inheritance;

public class Parent {

    public void execute() {
        System.out.println("Execute parent code ...");
    }
}
