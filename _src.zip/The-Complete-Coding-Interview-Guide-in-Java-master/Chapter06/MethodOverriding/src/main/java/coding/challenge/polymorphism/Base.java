package coding.challenge.polymorphism;

public interface Base {

public void execute();
}
