package coding.challenge.good;

public interface TournamentOrganizer {
    
    public void organizeTournament();
}
