package coding.challenge.good;

public interface TournamentJoiner {
    
    public void joinTournament();
}
