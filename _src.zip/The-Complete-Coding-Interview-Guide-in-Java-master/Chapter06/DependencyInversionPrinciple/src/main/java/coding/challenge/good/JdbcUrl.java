package coding.challenge.good;

public interface JdbcUrl {
    
    public String get();
}
