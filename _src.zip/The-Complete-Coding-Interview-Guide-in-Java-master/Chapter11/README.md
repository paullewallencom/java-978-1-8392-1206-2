# Linked lists and maps
This chapter teaches you the 17 most famous coding challenges that involve maps and linked lists encountered in interviews. 
