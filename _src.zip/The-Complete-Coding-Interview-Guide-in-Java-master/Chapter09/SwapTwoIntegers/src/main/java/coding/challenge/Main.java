package coding.challenge;

public class Main {

    public static void main(String[] args) {

        Bits.swap(2, 4);
        Bits.swap(-2, 4);
        Bits.swap(0, 1);
        Bits.swap(42, 11);
    }

}
