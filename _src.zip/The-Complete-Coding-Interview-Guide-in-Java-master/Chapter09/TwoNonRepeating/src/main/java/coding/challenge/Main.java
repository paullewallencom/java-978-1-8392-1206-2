package coding.challenge;
 
public class Main {

    public static void main(String[] args) {
        
        int[] arr = {2, 7, 1, 5, 9, 4, 1, 2, 5, 4};
        
        Bits.findNonRepeatable(arr);
    }

}
