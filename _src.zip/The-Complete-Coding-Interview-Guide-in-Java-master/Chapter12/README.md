# Linked lists and maps
This chapter explains the 11 most popular interview coding challenges involving stacks and queues. Mainly, you have to learn how to provide a stack/queue implementation from scratch and how to tackle coding challenges via the Java built-in implementations.
