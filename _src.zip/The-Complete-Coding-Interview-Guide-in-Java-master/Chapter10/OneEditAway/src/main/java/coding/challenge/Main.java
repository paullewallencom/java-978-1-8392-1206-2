package coding.challenge;
 
public class Main {

    public static void main(String[] args) {

        String q = "tank";
        String p = "tlank";

        System.out.println("Result: " + Strings.isOneEditAway(q, p));                
    }

}
